from random import randint


# Function to read in text file with existing accounts
def readfile(acc_numbers, balances, names):
    file = open('bank.txt')
    for line in file:                                           # For every line in text file
        if line != "":                                          # If the line isn't a blank line
            line = line.split()                                 # Splitting the line up by every " ", returns list
            acc_numbers.append(int(line[0]))                    # Adding the account number from line
            balances.append(float(line[1]))                     # Adding the balances from line
            names.append(line[2] + " " + line[3])               # Adding the name from line


# Function to find index of account by account number
def find_account(acc_num, acc_numbers):
    for i in range(len(acc_numbers)):
        if acc_num == acc_numbers[i]:
            return i
    return ""                                                   # return empty string


# Function to open a new account
def find_index(customer_acc_num, acc_numbers):
    index = find_account(customer_acc_num, acc_numbers)         # has index to check for account.
    return index


# Function to open a new account
def open_acc(customer_acc_num, acc_numbers, balances, names):
    print('Press 1 to open account.')
    print('Press 2 to exit.')
    pick = str(input())
    if pick == "1":
        p_name = input('What is your name?')
        if len(p_name.split()) != 2:                                   # If user hasn't entered a name in correct format
            print("First name and last name initial.")
            open_acc(customer_acc_num, acc_numbers, balances, names)   # Calls function again so user can try again
            return                                                     # Stops program from continuing after 'restart'
        for i in range(len(p_name)):                                   # Else, for every character they entered
            if not p_name[i].isalpha() and not p_name[i] == " ":       # If it isn't a character (letter) or space
                print('Only letters.')
                open_acc(customer_acc_num, acc_numbers, balances, names)    # Calls function again so user can try again
                return                                                   # Stops program from continuing after 'restart'
        names.append(p_name)
        balances.append(0)
        p_acc_num = randint(100000, 1000000)
        while p_acc_num in acc_numbers:
            p_acc_num = randint(100000, 1000000)
        acc_numbers.append(p_acc_num)
        current_acc = p_acc_num
        menu(current_acc, acc_numbers, balances, names)                     # User goes back to option menu
    elif pick == "2":
        print("Well, maybe another time.")
        option_section(customer_acc_num, acc_numbers, balances, names)      # User goes back to option menu
    else:                                                                   # User has not entered in a 1 or 2
        print("We'll try this again.")
        open_acc(customer_acc_num, acc_numbers, balances, names)            # Calls function again so user can try again
    option_section(customer_acc_num, acc_numbers, balances, names)

# Function displaying options to users
def menu(customer_acc_num, acc_numbers, balances, names):
    index = find_account(customer_acc_num, acc_numbers)         # checks file of that entered to what is located in file
    print("Your details are ---> " + " Account Number:" + str(acc_numbers[index])  # prints users details
          + " Balance: €" + str(balances[index]) + " Name:" + names[index])
    return index, str(balances[index])


# Function to close an account
def close_acc(customer_acc_num, acc_numbers, balances, names):
    try:
        print('Press 1 to close account.')
        print('Press 2 to exit.')
        pick = str(input(""))
        if pick == "1":
            acc_num = int(input("Enter the account number that you wish to close."))
            for i in range(len(acc_numbers)):
                if acc_numbers[i] == acc_num:                                       # checks if account is in text file
                    acc_numbers.remove(acc_numbers[i])                              # will remove account numbers
                    balances.remove(balances[i])                                    # will remove balances
                    names.remove(names[i])                                          # will remove names
                    option_section(customer_acc_num, acc_numbers, balances, names)
                    return
            print("That account doesn't exist")
            close_acc(customer_acc_num, acc_numbers, balances, names)
        elif pick == "2":
            print("Well, maybe another time.")
            option_section(customer_acc_num, acc_numbers, balances, names)
        else:
            print("We'll try this again.")
            open_acc(customer_acc_num, acc_numbers, balances, names)
    except ValueError:                                                          # Occurs if the try is unsuccessful
        print()
        close_acc(customer_acc_num, acc_numbers, balances, names)


# Function allowing user to withdraw from account
def withdraw(customer_acc_num, acc_numbers, balances, names):
    try:
        print('Press 1 to withdraw from an account.')
        print('Press 2 to exit.')
        pick = str(input(""))
        if pick == "1":
            acc_num = int(input("Enter the account number you would like to withdraw from."))
            for i in range(len(acc_numbers)):                                   # checks list to see what is in there
                if acc_num == acc_numbers[i]:                                   # checks if number entered is in list
                    money = int(input("How much would you like to withdraw?"))
                    if money < 0:
                        print("Error. You can't withdraw a negative number.")
                        withdraw(customer_acc_num, acc_numbers, balances, names)
                    elif money > balances[i]:
                        print("Error.")
                        withdraw(customer_acc_num, acc_numbers, balances, names)
                    elif money < balances[i]:
                        balances[i] -= money                                    # money will be tacking from balances
                        print("Your details are ---> " + " Account Number:" + str(acc_numbers[i])
                              + " Balance: €" + str(balances[i]) + " Name:" + names[i])
                        option_section(customer_acc_num, acc_numbers, balances, names)
                        return
        elif pick == "2":
            print("Well, maybe another time.")
            option_section(customer_acc_num, acc_numbers, balances, names)
        print("That account doesn't exist.")
        withdraw(customer_acc_num, acc_numbers, balances, names)
    except ValueError:                                              # Occurs if the try is unsuccessful
        print()
        withdraw(customer_acc_num, acc_numbers, balances, names)


# Function allowing users to deposit money
def deposit(customer_acc_num, acc_numbers, balances, names):
    try:
        print('Press 1 to deposit to an account.')
        print('Press 2 to exit.')
        pick = str(input(""))
        if pick == "1":
            amount_des = int(input("Enter the account number you would like to deposit too from."))
            for i in range(len(acc_numbers)):                                      # checks file to see what is in there
                if amount_des == acc_numbers[i]:                                   # checks if number entered is in file
                    money = int(input("How much would you like to Deposit?"))
                    if money < 0:
                        print("Error. You can't deposit a negative number.")
                        deposit(customer_acc_num, acc_numbers, balances, names)
                    else:
                        balances[i] += money                                        # money is added to balances
                        print("Your details are ---> " + " Account Number:" + str(acc_numbers[i])
                              + " Balance: €" + str(balances[i]) + " Name:" + names[i])
                        option_section(customer_acc_num, acc_numbers, balances, names)
                        return
        elif pick == "2":
            print("Well, maybe another time.")
            option_section(customer_acc_num, acc_numbers, balances, names)
        print("That account doesn't exist.")
        deposit(customer_acc_num, acc_numbers, balances, names)

    except ValueError:                                                          # Occurs if try function is unsuccessful
        print()
        deposit(customer_acc_num, acc_numbers, balances, names)


# Function that generates report on what is in the text file
def report(customer_acc_num, acc_numbers, balances, names):
    access_code = input("Please enter the access code.")

    if access_code == "1622" or access_code == "access":
        total = 0
        print("The report reads:")
        print("Names------Acc Nums-----Balance---")

        for i in range(len(names)):
            print("% -10s %d % 10d" % (names[i], acc_numbers[i], balances[i]))
        print()
        for x in balances:
            total += float(x)
        print("The total amount in the bank is €", total)
        richest = ""
        max_money = 0
        i = 0
        while i < len(acc_numbers):
            if max_money < balances[i]:
                max_money = balances[i]
                richest = names[i]
            elif max_money == balances[i]:                                # if more than one person with the same amount
                richest += ", " + names[i]
            i += 1
        print(richest, "has/have the most money with €", max_money, )
        print()
        print("If you would like to go back to the menu please press the enter key.")
        print()
        print("Otherwise press 1 to quit")
        print()
        go_back = str(input())
        if go_back == "":
            option_section(customer_acc_num, acc_numbers, balances, names)
        elif go_back == "1":
            print("We hope to see you soon.")
        else:
            print("Something has gone wrong")
            print("To avoid damages, we are going to exit the bank for now.")
            exit()
    else:
        print("Access denied")
        option_section(customer_acc_num, acc_numbers, balances, names)


# Function that quits the program
def quit_option(acc_numbers, balances, names):
    file = open("bank.txt", "w+")                               # will write to a text file
    i = 0
    # text = ""
    while i < len(acc_numbers):                                 # will save new information
        text = str(acc_numbers[i]) + " " + str(balances[i]) + " " + names[i] + "\n"
        file.write(str(text))
        i += 1
    file.close()                                                # closes the file
    exit()


def option_section(customer_acc_num, acc_numbers, balances, names):
    index = find_account(customer_acc_num, acc_numbers)
    print("Please choose from the 6 options below.")
    print("1---> New Account  2 --->Close Account  3--->Withdraw  4--->Deposit  5--->Report  6--->Quit")
    option = str(input())
    if option == "1":
        open_acc(customer_acc_num, acc_numbers, balances, names)
    elif option == "2":
        close_acc(customer_acc_num, acc_numbers, balances, names)
    elif option == "3":
        withdraw(customer_acc_num, acc_numbers, balances, names)
    elif option == "4":
        deposit(customer_acc_num, acc_numbers, balances, names)
    elif option == "5":
        report(customer_acc_num, acc_numbers, balances, names)
    elif option == "6":
        quit_option(acc_numbers, balances, names)
    elif option == "":
        option_section(customer_acc_num, acc_numbers, balances, names)
    else:
        print("Error")
        option_section(customer_acc_num, acc_numbers, balances, names)
    return index, customer_acc_num


# main function
def main():
    acc_numbers = []
    balances = []
    names = []
    readfile(acc_numbers, balances, names)
    customer_acc_num = ""
    index = find_account(customer_acc_num, acc_numbers)
    print("Welcome to the Bank")
    print()
    option_section(index, acc_numbers, balances, names)
    return acc_numbers, balances, names


main()
